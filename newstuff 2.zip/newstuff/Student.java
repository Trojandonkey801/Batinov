//package batinov;
import java.io.IOException;
public class Student extends user{
	public Student(int port,String host, String userName)throws IOException{
		super(port,host,userName);
	}
}
